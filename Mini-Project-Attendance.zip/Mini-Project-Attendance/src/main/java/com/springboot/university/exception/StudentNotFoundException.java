package com.springboot.university.exception;


public class StudentNotFoundException extends Exception{
	
	
	public StudentNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
