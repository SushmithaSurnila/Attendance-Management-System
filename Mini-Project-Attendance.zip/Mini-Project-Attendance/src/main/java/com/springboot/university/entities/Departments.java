package com.springboot.university.entities;

public class Departments {
	
}
