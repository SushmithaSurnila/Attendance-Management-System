package com.springboot.university.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.springboot.university.entities.Student;
import com.springboot.university.repository.StudentRepository;

@Service
public class Studentservice {
	
	@Autowired
	private StudentRepository repository;
	
	public List<Student> getAllStudents()  
	{    
	List<Student> student = new ArrayList<>();    
	repository.findAll().forEach(student::add);    
	return student;    
	} 
	
	public void addStudent(Student student)  
	{    
	repository.save(student);    
	}
	
	public void updateStudent(Student student)  
	{    
	repository.save(student);    
	}

	

	

}
