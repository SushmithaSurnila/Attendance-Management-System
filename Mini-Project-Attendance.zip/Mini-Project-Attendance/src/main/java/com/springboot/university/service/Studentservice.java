package com.springboot.university.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Supplier;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.springboot.university.entities.Department;
import com.springboot.university.entities.Student;
import com.springboot.university.exception.StudentNotFoundException;
import com.springboot.university.repository.StudentRepository;

@Service
public class Studentservice {
	
	@Autowired
	private StudentRepository studentRepository;
		
	public List<Student> getAllStudents()  
	{    
	List<Student> student = new ArrayList<>();    
	studentRepository.findAll().forEach(student::add);    
	return student;    
	} 

	public void addStudent(Student student)  
	{    
	studentRepository.save(student);    
	}
	
	
	public Student getStudentByID(Long studentId) {
       Optional<Student> opt = studentRepository.findById(studentId);
       if (opt.isPresent())
           return opt.get();
        else
            return null;
    }

	public void updateStudent(Student  student) throws StudentNotFoundException 
	{
		
		Student st=studentRepository.findById(student.getStudentId())
				.orElseThrow(()-> new StudentNotFoundException("No student with id"));
	
		
	    //if(student.getLeaves()!=0)
	   // {
	    	//if(student.getLeaves()<=student.getAvailableNumberOfLeaves())
	    	//{
	    		//st.setAvailableNumberOfLeaves(student.getAvailableNumberOfLeaves()-student.getLeaves());
	    		//st.setLeaves(student.getLeaves());
	    	//}
	          		
	    //}
	    studentRepository.save(st);		
	}
	
	
	
	public void deleteStudentById(Long studentId)
	{
		studentRepository.deleteById(studentId);
	}
	
	

	

	
}
