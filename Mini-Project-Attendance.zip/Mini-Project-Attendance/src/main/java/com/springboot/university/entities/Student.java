package com.springboot.university.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Student {
	
	private String name;
	
	private String gender;
	@Id
	private Long studentid;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Address address;
	
	private long departmentid;
	
	private long phonenumber;

	public long getDepartmentid() {
		return departmentid;
	}

	public void setDepartmentid(long departmentid) {
		this.departmentid = departmentid;
	}

	public long getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getStudentid() {
		return studentid;
	}

	public void setStudentid(Long studentid) {
		this.studentid = studentid;
	}

	public Student(String name, String gender, Long studentid, Address address, long departmentid, long phonenumber) {
		super();
		this.name = name;
		this.gender = gender;
		this.studentid = studentid;
		this.address = address;
		this.departmentid = departmentid;
		this.phonenumber = phonenumber;
	}
}
