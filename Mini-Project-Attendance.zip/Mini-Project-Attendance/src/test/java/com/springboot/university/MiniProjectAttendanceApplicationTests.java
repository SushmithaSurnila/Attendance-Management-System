package com.springboot.university;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProjectAttendanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
