package com.springboot.university.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.university.entities.Student;
import com.springboot.university.repository.StudentRepository;

@Service
public class Studentservice {
	
	@Autowired
	private StudentRepository repository;
	
	private int availableNumberOfLeaves=10;

	
	public List<Student> getAllStudents()  
	{    
	List<Student> student = new ArrayList<>();    
	repository.findAll().forEach(student::add);    
	return student;    
	} 
	
	public void addStudent(Student student)  
	{    
	repository.save(student);    
	}
	
	 public Student findAllStudentByID(Long studentid) {
	        Optional<Student> opt = repository.findById(studentid);
	        if (opt.isPresent())
	            return opt.get();
	        else
	            return null;
	        
	        
	 }
	
	public void updateStudent(Student student)  
	{    
	repository.save(student);
	}

	public void deleteAStudent(Student student) {
		repository.delete(student);
		
	}
	public void deleteStudent(Student student)  
	{    
	repository.delete(student);    
	}
	
	
	public int leaves(Student student)
	{
		int studentLeaves=student.getLeaves();
		
		availableNumberOfLeaves = availableNumberOfLeaves-studentLeaves;
		return availableNumberOfLeaves;
	}
	

	
}
