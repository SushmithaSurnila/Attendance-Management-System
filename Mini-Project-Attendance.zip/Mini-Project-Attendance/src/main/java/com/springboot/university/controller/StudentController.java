package com.springboot.university.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.springboot.university.entities.Student;

import com.springboot.university.service.Studentservice;


@RestController
public class StudentController {
	
	@Autowired
	private Studentservice stuservice;

	
	@GetMapping("/getall")
	public List<Student> getAllStudents()  
	{    
	return stuservice.getAllStudents();    
	}
	
	
	@PostMapping("/saveall")
	public void addStudent(@RequestBody Student student)
	{
		stuservice.addStudent(student);
	}
	
	@PutMapping("/update")
	public void updateStudent(@RequestBody Student student)
	{
		stuservice.updateStudent(student);
	}
	
	

	

}
