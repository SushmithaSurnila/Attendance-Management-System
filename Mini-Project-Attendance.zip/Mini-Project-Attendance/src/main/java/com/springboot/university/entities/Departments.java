package com.springboot.university.entities;

import jakarta.persistence.Entity;

@Entity
public class Departments {
	
	private Long depId;
	
	private String deptname;

	public Departments(Long depId, String deptname) {
		super();
		this.depId = depId;
		this.deptname = deptname;
	}

	public Long getDepId() {
		return depId;
	}

	public void setDepId(Long depId) {
		this.depId = depId;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
	
	
}
