package com.springboot.university.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.university.entities.Student;

import com.springboot.university.service.Studentservice;

@RestController
public class StudentController {
	
	@Autowired
	private Studentservice stuservice;

	
	@GetMapping("/student")
	public List<Student> getAllStudents()  
	{    
	return stuservice.getAllStudents();
	
	}	
	
	@GetMapping("/findbyId/{studentid}")
	public Student getStudentUsingId(@PathVariable Long studentid) {
		return stuservice.findAllStudentByID(studentid);
	}
	
	
	
	@PostMapping("/save")
	public String addStudent(@RequestBody Student student)
	{
		stuservice.addStudent(student);
		return "Student details saved";		
	}
	
	@PutMapping("/update")
	public void updateStudent(@RequestBody Student student)
	{
		
		stuservice.updateStudent(student);
		stuservice.leaves(student);

	}
	
	@DeleteMapping("/delete/student/by/{studentId}")
	public void deleteAStudent(@PathVariable Student student) {
		stuservice.deleteAStudent(student);
	}
	

}
